Thanks for downloading or buying it.

New update has improved performance, inverted color option, new responsive UI and Drag'n Drop.

We hope this tool help you!

Matheus Dalla, Rovann Linhalis.